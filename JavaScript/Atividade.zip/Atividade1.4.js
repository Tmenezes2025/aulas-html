let idade = prompt("Por favor inform sua idade")

if (idade >= 18) {
    alert("Você é maior de idade")
} else {
    alert("Você é menor de idade")
}

