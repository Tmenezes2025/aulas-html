// 1. Cria a lista com os itens
let listaDeItens = ["Arroz", "Feijão", "Carne"];

// 2. Exibe todos os itens da lista no console usando um loop for
for (let i = 0; i < listaDeItens.length; i++) {
  console.log(listaDeItens[i]);
}
