let numero = 0;
while(numero <= 10) {
    document.write(`${numero} <br>`)
    numero++
}