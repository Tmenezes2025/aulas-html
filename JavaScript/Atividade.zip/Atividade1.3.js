let nome = prompt ( "Inform o Seu nome")

alert ("Olá, " + nome + "! Seja bem-vindo!")