let numero1 = 5
let numero2 = 10 

let soma = numero1 + numero2
let Subtração = numero1 - numero2

console.log(`A soma dos numeros é ${soma}`)
console.log (`A subtração dos numeros é ${subtração}`)