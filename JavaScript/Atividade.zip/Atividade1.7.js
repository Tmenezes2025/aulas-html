
let numeroAleatorio = Math.floor(Math.random() * 100) + 1;

console.log("O número aleatório gerado é:", numeroAleatorio);
